from pathlib import Path
from datetime import datetime
from collections import Counter, defaultdict
import csv
import hashlib
import importlib.util
import json
import shutil
import sys
import time

import PIL

ROOT = Path("/home/gpuserver2/QC_Rebuild_v1")
SOURCE = Path(
    "/home/gpuserver2/datasets/nantes_v3/extracted/f0/embryo_dataset"
)
SNAPSHOT = ROOT / "data/qc30_labels_v1_20261023_155615_176150"
INDEX = SNAPSHOT / "qc30_frame_index.csv"

def require(ok, message):
    if not ok:
        raise SystemExit("停止：" + message)

def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def write_csv(path, rows, fields):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

# 先验证最终标注快照，避免读到被意外修改的索引。
manifest = SNAPSHOT / "SHA256SUMS"
require(manifest.is_file(), "找不到快照校验清单")
for line in manifest.read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    digest, name = line.split("  ", 1)
    require(Path(name).name == name, "校验清单文件名异常")
    path = SNAPSHOT / name
    require(path.is_file() and sha256(path) == digest,
            "快照校验失败：" + name)

with INDEX.open("r", encoding="utf-8-sig", newline="") as f:
    reader = csv.DictReader(f)
    original_fields = reader.fieldnames or []
    rows = list(reader)

required = {
    "embryo_id", "focal_plane", "run", "image_path",
    "qc_split", "action", "label_invalid", "review_status"
}
require(required.issubset(original_fields), "索引缺少必要列")
require(len(rows) == 14061, "索引不是14061帧")
require(Counter(r["action"] for r in rows)
        == Counter({"KEEP": 11995, "DELETE": 2066}),
        "标签数量与最终标注不一致")

embryo_split = {}
keys = set()
paths = set()
for row in rows:
    require(None not in row
            and all(v is not None for v in row.values()),
            "索引列数异常")
    embryo = row["embryo_id"]
    split = row["qc_split"]
    run = int(row["run"])
    path = Path(row["image_path"])
    require(split in ("train", "val"), "索引混入非开发集数据")
    require(row["focal_plane"] == "F0"
            and row["review_status"] == "reviewed",
            "存在非F0或未复核记录")
    require(row["label_invalid"]
            == ("1" if row["action"] == "DELETE" else "0"),
            "数字标签与KEEP/DELETE不一致")
    require(path.parent == SOURCE / embryo, "原图目录与胚胎ID不符")
    require(path.stem.upper().endswith("_RUN" + str(run)),
            "原图文件名与RUN不符")
    key = (embryo, run)
    require(key not in keys and str(path) not in paths,
            "索引存在重复帧")
    keys.add(key)
    paths.add(str(path))
    require(embryo not in embryo_split
            or embryo_split[embryo] == split,
            "同一胚胎跨训练/验证分组")
    embryo_split[embryo] = split

require(Counter(embryo_split.values())
        == Counter({"train": 24, "val": 6}),
        "分组不是24 train + 6 val")

STAMP = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
OUT = ROOT / "data" / ("qc30_decode_audit_v1_" + STAMP)
OUT.mkdir(parents=True, exist_ok=False)

# 保存统一读取函数，后续训练可以复用这一份实现。
loader_code = r'''
from io import BytesIO
from pathlib import Path
from PIL import Image, ImageFile

POLICY = "strict_then_jpeg_truncated_fallback_v1"

class QCDecodeError(RuntimeError):
    def __init__(self, metadata):
        self.metadata = dict(metadata)
        super().__init__(
            metadata.get("fallback_error")
            or metadata.get("strict_error")
            or "decode failed"
        )

def _decode_once(data, allow_truncated, metadata):
    previous = ImageFile.LOAD_TRUNCATED_IMAGES
    try:
        ImageFile.LOAD_TRUNCATED_IMAGES = allow_truncated
        with Image.open(BytesIO(data)) as source:
            metadata["image_format"] = source.format or ""
            metadata["source_mode"] = source.mode
            metadata["width"], metadata["height"] = source.size
            source.load()
            rgb = source.convert("RGB")
            rgb.load()
        return rgb
    finally:
        ImageFile.LOAD_TRUNCATED_IMAGES = previous

def decode_qc_rgb(data):
    metadata = {
        "decode_mode": "FAILED",
        "image_format": "",
        "source_mode": "",
        "width": "",
        "height": "",
        "strict_error": "",
        "fallback_error": "",
    }
    try:
        rgb = _decode_once(data, False, metadata)
    except Exception as error:
        metadata["strict_error"] = (
            type(error).__name__ + ": " + str(error)
        )
        eligible = (
            metadata["image_format"] == "JPEG"
            and isinstance(error, OSError)
            and "truncated" in str(error).lower()
        )
        if not eligible:
            raise QCDecodeError(metadata) from error
        try:
            rgb = _decode_once(data, True, metadata)
        except Exception as fallback_error:
            metadata["fallback_error"] = (
                type(fallback_error).__name__
                + ": " + str(fallback_error)
            )
            raise QCDecodeError(metadata) from fallback_error
        metadata["decode_mode"] = "TRUNCATED_ALLOWED"
    else:
        metadata["decode_mode"] = "STRICT_OK"
    return rgb, metadata

def load_qc_rgb(path):
    return decode_qc_rgb(Path(path).read_bytes())
'''
loader_path = OUT / "qc_image_io_v1.py"
loader_path.write_text(loader_code, encoding="utf-8")
shutil.copy2(Path(__file__), OUT / "audit_script.py")

spec = importlib.util.spec_from_file_location(
    "qc_image_io_audited", str(loader_path)
)
loader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(loader)

audit_fields = [
    "embryo_id", "qc_split", "run", "image_path",
    "action", "label_invalid", "file_bytes", "source_sha256",
    "decode_mode", "image_format", "source_mode",
    "width", "height", "strict_error", "fallback_error"
]
audit = []
totals = Counter()
per_embryo = defaultdict(Counter)
started = time.monotonic()

print("开始逐帧解码审计：14061张图", flush=True)
print("输出目录：" + str(OUT), flush=True)

# 边检查边记录，意外中断时保留已经完成的审计行。
with (OUT / "decode_audit.csv").open(
    "w", encoding="utf-8-sig", newline=""
) as f:
    writer = csv.DictWriter(f, fieldnames=audit_fields)
    writer.writeheader()

    for number, row in enumerate(rows, 1):
        record = {key: row[key] for key in (
            "embryo_id", "qc_split", "run", "image_path",
            "action", "label_invalid"
        )}
        record.update({
            "file_bytes": "",
            "source_sha256": "",
            "decode_mode": "FAILED",
            "image_format": "",
            "source_mode": "",
            "width": "",
            "height": "",
            "strict_error": "",
            "fallback_error": "",
        })

        try:
            path = Path(row["image_path"])
            before = path.stat()
            data = path.read_bytes()
            after = path.stat()
            if (before.st_size, before.st_mtime_ns) != (
                after.st_size, after.st_mtime_ns
            ):
                raise RuntimeError("检查期间原图发生变化")
            record["file_bytes"] = len(data)
            record["source_sha256"] = hashlib.sha256(data).hexdigest()
            rgb, metadata = loader.decode_qc_rgb(data)
            try:
                record.update(metadata)
            finally:
                rgb.close()
        except loader.QCDecodeError as error:
            record.update(error.metadata)
        except Exception as error:
            record["decode_mode"] = "FAILED"
            record["fallback_error"] = (
                type(error).__name__ + ": " + str(error)
            )

        writer.writerow(record)
        audit.append(record)
        totals[record["decode_mode"]] += 1
        per_embryo[row["embryo_id"]][record["decode_mode"]] += 1

        if number % 250 == 0 or number == len(rows):
            f.flush()
            print(
                "{}/{} | STRICT {} | COMPAT {} | FAILED {} | {:.1f}s".format(
                    number, len(rows), totals["STRICT_OK"],
                    totals["TRUNCATED_ALLOWED"], totals["FAILED"],
                    time.monotonic() - started
                ),
                flush=True
            )

summary = []
for embryo, split in embryo_split.items():
    counts = per_embryo[embryo]
    summary.append({
        "embryo_id": embryo,
        "qc_split": split,
        "STRICT_OK": counts["STRICT_OK"],
        "TRUNCATED_ALLOWED": counts["TRUNCATED_ALLOWED"],
        "FAILED": counts["FAILED"],
    })

write_csv(OUT / "embryo_decode_summary.csv",
          summary, list(summary[0]))
write_csv(OUT / "decode_failed.csv",
          [r for r in audit if r["decode_mode"] == "FAILED"],
          audit_fields)

report = {
    "status": "PASS" if totals["FAILED"] == 0 else "NEEDS_REVIEW",
    "python": sys.executable,
    "pillow": PIL.__version__,
    "decode_policy": loader.POLICY,
    "loader_sha256": sha256(loader_path),
    "audit_script_sha256": sha256(OUT / "audit_script.py"),
    "label_snapshot": str(SNAPSHOT),
    "source_index_sha256": sha256(INDEX),
    "frames": len(rows),
    "counts": dict(totals),
    "elapsed_seconds": time.monotonic() - started,
    "raw_images_modified": False,
    "labels_modified": False,
    "scope": "train/val only; no independent test images",
    "note": "Decodability does not establish visual image quality.",
}

# 只有全部可读取时，才生成供下一步使用的完整审计后索引。
if totals["FAILED"] == 0:
    extra = [
        "decode_mode", "source_sha256", "file_bytes",
        "image_format", "source_mode", "width", "height"
    ]
    require(not set(extra).intersection(original_fields),
            "新索引列名与原索引冲突")
    merged = [
        dict(row, **{key: check[key] for key in extra})
        for row, check in zip(rows, audit)
    ]
    write_csv(
        OUT / "qc30_frame_index_audited.csv",
        merged, original_fields + extra
    )

(OUT / "audit_protocol.json").write_text(
    json.dumps(report, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8"
)
checksums = [
    sha256(p) + "  " + p.name
    for p in sorted(OUT.iterdir()) if p.is_file()
]
(OUT / "SHA256SUMS").write_text(
    "\n".join(checksums) + "\n", encoding="utf-8"
)

print("\n逐胚胎汇总：")
for row in summary:
    print("{embryo_id} [{qc_split}] STRICT {STRICT_OK} "
          "COMPAT {TRUNCATED_ALLOWED} FAILED {FAILED}".format(**row))

print("\n最终状态：" + report["status"])
print("STRICT_OK：" + str(totals["STRICT_OK"]))
print("TRUNCATED_ALLOWED：" + str(totals["TRUNCATED_ALLOWED"]))
print("FAILED：" + str(totals["FAILED"]))
print("输出目录：" + str(OUT))
print("原图、人工标签、固定分组均未修改。")

if totals["FAILED"]:
    print("存在读取失败，请先核查decode_failed.csv，暂不训练。")
    raise SystemExit(2)

print("PASS：全部14061张图均可按记录的读取策略解码。")
print("尚未进行模型输入预处理或正式训练。")
