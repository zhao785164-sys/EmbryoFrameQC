from pathlib import Path
from datetime import datetime
import argparse
import csv
import math
import re
from PIL import Image, ImageDraw, ImageFont

parser = argparse.ArgumentParser()
parser.add_argument("--embryo", required=True)
args = parser.parse_args()

root = Path("/home/gpuserver2/QC_Rebuild_v1")
source = (
    Path("/home/gpuserver2/datasets/nantes_v3/extracted")
    / "f0" / "embryo_dataset" / args.embryo
)
if not source.is_dir():
    raise SystemExit(f"找不到胚胎目录：{source}")

# RUN 必须按数字排序，避免 RUN1、RUN10、RUN100 的字典序。
records = []
seen = set()
for p in source.iterdir():
    if not p.is_file() or p.suffix.lower() not in {
        ".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"
    }:
        continue
    match = re.search(r"_RUN(\d+)$", p.stem, re.IGNORECASE)
    if not match:
        raise SystemExit(f"无法解析 RUN 编号，停止：{p.name}")
    run = int(match.group(1))
    if run in seen:
        raise SystemExit(f"存在重复 RUN{run}，请先核查，停止。")
    seen.add(run)
    records.append((run, p))

records.sort(key=lambda item: item[0])
if not records:
    raise SystemExit("没有找到图像。")

stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
out = root / "montages" / f"{args.embryo}_F0_{stamp}"
out.mkdir(parents=True, exist_ok=False)

font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
def font(size):
    try:
        return ImageFont.truetype(font_path, size)
    except OSError:
        return ImageFont.load_default()

title_font = font(22)
label_font = font(18)
resample = getattr(Image, "Resampling", Image).LANCZOS
errors = {}

def draw_sheet(items, filename, title, cols, side):
    gap, label_h, header = 12, 30, 65
    rows = math.ceil(len(items) / cols)
    width = gap + cols * (side + gap)
    height = header + rows * (side + label_h + gap)
    canvas = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(canvas)
    draw.text((gap, 10), title, font=title_font, fill="black")
    draw.text(
        (gap, 37), "Raw images | resized only | no brightness normalization",
        font=label_font, fill="#444444"
    )

    for i, (run, path) in enumerate(items):
        x = gap + (i % cols) * (side + gap)
        y = header + (i // cols) * (side + label_h + gap)
        draw.rectangle((x, y, x + side - 1, y + side - 1), fill="#dddddd")
        try:
            with Image.open(path) as original:
                original.load()
                im = original.convert("RGB")
            im.thumbnail((side, side), resample)
            canvas.paste(
                im, (x + (side - im.width) // 2, y + (side - im.height) // 2)
            )
        except Exception as exc:
            errors[str(path)] = str(exc)
            draw.text((x + 8, y + 20), "DECODE ERROR",
                      font=label_font, fill="red")

        draw.text((x + 5, y + side + 4), f"RUN {run}",
                  font=label_font, fill="black")

    canvas.save(out / filename)
    print("已生成：", filename, flush=True)

# 概览仅供定位，不能替代全部帧复核。
count = min(48, len(records))
indices = (
    [0] if count == 1
    else [round(i * (len(records) - 1) / (count - 1)) for i in range(count)]
)
draw_sheet(
    [records[i] for i in indices],
    "00_overview.png",
    f"{args.embryo} | F0 | overview ({count}/{len(records)} frames)",
    cols=8, side=192
)

# 每页36帧，完整覆盖该目录的所有图像。
page_size = 36
total_pages = math.ceil(len(records) / page_size)
for page, start in enumerate(range(0, len(records), page_size), 1):
    items = records[start:start + page_size]
    draw_sheet(
        items,
        f"page_{page:03d}_RUN{items[0][0]}-{items[-1][0]}.png",
        f"{args.embryo} | F0 | page {page}/{total_pages}",
        cols=6, side=256
    )

with (out / "frame_index.csv").open("w", encoding="utf-8-sig", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["embryo_id", "focal_plane", "run", "image_path",
                     "review_page", "decode_status"])
    for i, (run, path) in enumerate(records):
        writer.writerow([
            args.embryo, "F0", run, str(path), i // page_size + 1,
            "ERROR" if str(path) in errors else "OK"
        ])

with (out / "decode_errors.csv").open("w", encoding="utf-8-sig", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["image_path", "error"])
    writer.writerows(sorted(errors.items()))

missing = sorted(set(range(records[0][0], records[-1][0] + 1)) - seen)
print("\n胚胎：", args.embryo)
print("实际图像数：", len(records))
print("RUN 范围：", records[0][0], "-", records[-1][0])
print("范围内缺失 RUN 数：", len(missing))
print("缺失 RUN 示例：", missing[:30])
print("解码失败数：", len(errors))
print("输出目录：", out)
print("完成：未修改原始图像，未自动填写任何人工标签。")
