from pathlib import Path
from datetime import datetime
from collections import Counter
from urllib.parse import urlsplit
import csv
import hashlib
import importlib.util
import json
import random
import shutil
import socket

import PIL
from PIL import Image, ImageOps, ImageDraw, ImageFont
import numpy as np
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
import torchvision

ROOT = Path("/home/gpuserver2/QC_Rebuild_v1")
AUDIT = ROOT / "data/qc30_decode_audit_v1_20261023_162958_452370"
STAMP = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
SEED = 42

def require(ok, message):
    if not ok:
        raise SystemExit("停止：" + message)

def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def read_csv(path):
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        fields = reader.fieldnames
        rows = list(reader)
    require(bool(fields) and all(
        None not in r and all(v is not None for v in r.values())
        for r in rows
    ), "CSV结构异常：" + str(path))
    return fields, rows

def write_csv(path, fields, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

# 验证审计产物。
require((AUDIT / "SHA256SUMS").is_file(), "找不到指定解码审计目录")
for line in (AUDIT / "SHA256SUMS").read_text(
    encoding="utf-8"
).splitlines():
    if not line.strip():
        continue
    digest, name = line.split("  ", 1)
    require(Path(name).name == name, "清单文件名异常")
    path = AUDIT / name
    require(path.is_file() and sha256(path) == digest,
            "审计文件校验失败：" + name)

audit_protocol = json.loads(
    (AUDIT / "audit_protocol.json").read_text(encoding="utf-8")
)
require(audit_protocol["status"] == "PASS", "解码审计未通过")
require(audit_protocol["pillow"] == PIL.__version__,
        "Pillow版本与解码审计时不同")
require(torch.cuda.is_available(), "GPU不可用")

fields, rows = read_csv(AUDIT / "qc30_frame_index_audited.csv")
require(len(rows) == 14061, "索引数量不是14061")
require(Counter(r["action"] for r in rows)
        == Counter({"KEEP": 11995, "DELETE": 2066}),
        "标签数量异常")
require(all(r["review_status"] == "reviewed"
            and r["qc_split"] in ("train", "val")
            and r["decode_mode"] in ("STRICT_OK", "TRUNCATED_ALLOWED")
            and r["label_invalid"] == (
                "1" if r["action"] == "DELETE" else "0"
            ) for r in rows),
        "索引包含未复核、未知分组或标签冲突")

train_ids = {r["embryo_id"] for r in rows if r["qc_split"] == "train"}
val_ids = {r["embryo_id"] for r in rows if r["qc_split"] == "val"}
require(len(train_ids) == 24 and len(val_ids) == 6
        and not train_ids.intersection(val_ids), "胚胎分组异常")

OUT = ROOT / "runs" / ("qc_resnet18_smoke_v1_" + STAMP)
OUT.mkdir(parents=True, exist_ok=False)
shutil.copy2(Path(__file__), OUT / "smoke_script.py")
shutil.copy2(AUDIT / "qc_image_io_v1.py", OUT / "qc_image_io_v1.py")
image_io = load_module("qc_smoke_image_io", OUT / "qc_image_io_v1.py")

# 保存预处理实现，后续正式训练可复用。
preprocess_code = r'''
import numpy as np
import torch
from PIL import Image, ImageOps

def prepare_qc(rgb):
    gray = rgb.convert("L")
    arr = np.asarray(gray, dtype=np.float32)
    gray.close()
    lo, hi = np.percentile(arr, [1, 99])
    flat = bool(hi <= lo)
    if flat:
        output = arr.astype(np.uint8)
    else:
        output = np.rint(
            np.clip((arr - lo) / (hi - lo), 0, 1) * 255
        ).astype(np.uint8)

    normalized = Image.fromarray(output)
    fitted = ImageOps.contain(
        normalized, (224, 224), method=Image.Resampling.BILINEAR
    )
    canvas = Image.new("L", (224, 224), 0)
    canvas.paste(
        fitted, ((224 - fitted.width) // 2, (224 - fitted.height) // 2)
    )
    display = canvas.convert("RGB")
    normalized.close()
    fitted.close()
    canvas.close()

    values = np.array(display, dtype=np.float32) / 255.0
    tensor = torch.from_numpy(values).permute(2, 0, 1)
    mean = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
    std = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)
    tensor = (tensor - mean) / std
    return tensor, display, {
        "p01": float(lo), "p99": float(hi), "flat_percentiles": flat
    }
'''
preprocess_path = OUT / "qc_preprocess_v1.py"
preprocess_path.write_text(preprocess_code, encoding="utf-8")
preprocess = load_module("qc_smoke_preprocess", preprocess_path)

def read_verified(row):
    data = Path(row["image_path"]).read_bytes()
    require(hashlib.sha256(data).hexdigest() == row["source_sha256"],
            "原图与审计时不同：" + row["image_path"])
    rgb, metadata = image_io.decode_qc_rgb(data)
    if metadata["decode_mode"] != row["decode_mode"]:
        rgb.close()
        raise RuntimeError("解码方式与审计记录不同")
    return rgb

# 生成6组对比，每组两帧，每帧展示原图和预处理后图像。
lookup = {(r["embryo_id"], int(r["run"])): r for r in rows}
pairs = [
    [("AS556-3", 472), ("AS556-3", 473)],
    [("AM365-7", 177), ("AM365-7", 178)],
    [("AM716-7", 475), ("AM716-7", 476)],
    [("RG944-2", 372), ("RG944-2", 373)],
    [("CZ594-1", 169), ("CZ594-1", 180)],
    [("MC933-2", 364), ("MC933-2", 365)],
]
try:
    font = ImageFont.truetype(
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 13
    )
except OSError:
    font = ImageFont.load_default()

cell_w, cell_h = 248, 272
preview = Image.new("RGB", (cell_w * 4, 40 + cell_h * 6), "white")
draw = ImageDraw.Draw(preview)
draw.text((12, 10),
          "Raw vs QC input (displayed before ImageNet normalization)",
          fill="black", font=font)

for row_number, pair in enumerate(pairs):
    for item_number, key in enumerate(pair):
        require(key in lookup, "预览帧不在开发集索引中：" + str(key))
        row = lookup[key]
        rgb = read_verified(row)
        tensor, processed, stats = preprocess.prepare_qc(rgb)
        fitted = ImageOps.contain(
            rgb, (224, 224), method=Image.Resampling.BILINEAR
        )
        raw_view = Image.new("RGB", (224, 224), "black")
        raw_view.paste(
            fitted, ((224 - fitted.width) // 2, (224 - fitted.height) // 2)
        )
        for offset, (name, picture) in enumerate(
            (("RAW", raw_view), ("P1-P99", processed))
        ):
            x = (item_number * 2 + offset) * cell_w + 12
            y = 40 + row_number * cell_h
            caption = "{} RUN{}\n{} | {}".format(
                key[0], key[1], row["action"], name
            )
            draw.multiline_text(
                (x, y), caption, fill="black", font=font, spacing=3
            )
            preview.paste(picture, (x, y + 42))
        rgb.close()
        fitted.close()
        raw_view.close()
        processed.close()

preview.save(OUT / "input_preview.png")
preview.close()
print("输入预览已生成：" + str(OUT / "input_preview.png"), flush=True)

random.seed(SEED)
rng = random.Random(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)
torch.set_num_threads(2)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

# 从训练集中抽取80 KEEP和80 DELETE，组成10个平衡批次。
train_by_class = [
    [r for r in rows if r["qc_split"] == "train"
     and int(r["label_invalid"]) == label]
    for label in (0, 1)
]
train_samples = [rng.sample(pool, 80) for pool in train_by_class]
smoke_train = []
for step in range(10):
    batch = train_samples[0][step * 8:(step + 1) * 8] + \
            train_samples[1][step * 8:(step + 1) * 8]
    rng.shuffle(batch)
    smoke_train.extend(batch)

smoke_val = []
for label in (0, 1):
    pool = [
        r for r in rows if r["qc_split"] == "val"
        and int(r["label_invalid"]) == label
    ]
    smoke_val.extend(rng.sample(pool, 32))

write_csv(OUT / "smoke_train_samples.csv", fields, smoke_train)
write_csv(OUT / "smoke_val_samples.csv", fields, smoke_val)

class QCSet(Dataset):
    def __init__(self, records):
        self.records = records

    def __len__(self):
        return len(self.records)

    def __getitem__(self, index):
        row = self.records[index]
        rgb = read_verified(row)
        try:
            tensor, display, stats = preprocess.prepare_qc(rgb)
            display.close()
        finally:
            rgb.close()
        require(bool(torch.isfinite(tensor).all()), "输入张量有非有限值")
        return tensor, int(row["label_invalid"])

train_loader = DataLoader(
    QCSet(smoke_train), batch_size=16, shuffle=False, num_workers=0
)
val_loader = DataLoader(
    QCSet(smoke_val), batch_size=16, shuffle=False, num_workers=0
)

# 下载并校验官方预训练权重，已有文件则校验后复用。
weights = torchvision.models.ResNet18_Weights.IMAGENET1K_V1
weight_name = Path(urlsplit(weights.url).path).name
weight_path = ROOT / "weights" / weight_name
weight_path.parent.mkdir(parents=True, exist_ok=True)
hash_prefix = weight_name.rsplit("-", 1)[1].split(".")[0]

socket.setdefaulttimeout(60)
if not weight_path.is_file():
    print("下载官方预训练权重：" + weights.url, flush=True)
    torch.hub.download_url_to_file(
        weights.url, str(weight_path),
        hash_prefix=hash_prefix, progress=True
    )

weight_hash = sha256(weight_path)
require(weight_hash.startswith(hash_prefix), "预训练权重哈希校验失败")

state = torch.load(weight_path, map_location="cpu", weights_only=True)
model = torchvision.models.resnet18(weights=None)
model.load_state_dict(state, strict=True)
model.fc = nn.Linear(model.fc.in_features, 2)
model = model.to("cuda")
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.AdamW(
    model.parameters(), lr=1e-4, weight_decay=1e-4
)

config = {
    "purpose": "pipeline smoke test; not formal performance evaluation",
    "preprocessing_status": "candidate pending visual review",
    "seed": SEED,
    "physical_gpu": 0,
    "decode_audit": str(AUDIT),
    "audited_index_sha256":
        sha256(AUDIT / "qc30_frame_index_audited.csv"),
    "loader_sha256": sha256(OUT / "qc_image_io_v1.py"),
    "preprocess_sha256": sha256(preprocess_path),
    "preprocessing": (
        "grayscale; per-frame P1-P99 stretch; flat percentiles retain "
        "original intensities; full-view aspect-preserving resize and "
        "black padding to 224; repeat RGB; ImageNet mean/std"
    ),
    "weights_url": weights.url,
    "weights_path": str(weight_path),
    "weights_sha256": weight_hash,
    "train_steps": 10,
    "batch_size": 16,
    "learning_rate": 1e-4,
    "weight_decay": 1e-4,
    "train_sampling": "80 KEEP + 80 DELETE; balanced batches",
    "val_sampling": "32 KEEP + 32 DELETE; forward check only",
    "label_invalid": {"0": "KEEP", "1": "DELETE"},
    "independent_test_used": False,
    "versions": {
        "torch": torch.__version__, "torchvision": torchvision.__version__,
        "pillow": PIL.__version__, "numpy": np.__version__
    },
}
(OUT / "config.json").write_text(
    json.dumps(config, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8"
)

history = []
print("\n开始GPU0冒烟训练：10步", flush=True)
model.train()
for step, (images, labels) in enumerate(train_loader, 1):
    images, labels = images.to("cuda"), labels.to("cuda")
    optimizer.zero_grad(set_to_none=True)
    logits = model(images)
    loss = criterion(logits, labels)
    require(bool(torch.isfinite(loss)), "训练损失出现NaN/Inf")
    loss.backward()
    grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
    require(bool(torch.isfinite(grad_norm)), "梯度出现NaN/Inf")
    optimizer.step()
    value = float(loss.detach().cpu())
    history.append({"step": step, "loss": value})
    print("step {}/10 | loss {:.6f}".format(step, value), flush=True)

model.eval()
val_frames = 0
with torch.inference_mode():
    for images, labels in val_loader:
        logits = model(images.to("cuda"))
        require(tuple(logits.shape) == (len(labels), 2)
                and bool(torch.isfinite(logits).all()),
                "验证前向输出异常")
        val_frames += len(labels)

write_csv(OUT / "train_history.csv", ["step", "loss"], history)
torch.save({
    "purpose": "smoke_only_not_for_deployment",
    "model": {k: v.detach().cpu() for k, v in model.state_dict().items()},
    "config": config,
}, OUT / "smoke_checkpoint.pt")

result = {
    "status": "PASS",
    "train_steps": len(history),
    "val_forward_frames": val_frames,
    "output_classes": 2,
    "note": "No deployment threshold selected; no test-set evaluation.",
}
(OUT / "result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8"
)
manifest = [
    sha256(p) + "  " + p.name
    for p in sorted(OUT.iterdir()) if p.is_file()
]
(OUT / "SHA256SUMS").write_text(
    "\n".join(manifest) + "\n", encoding="utf-8"
)

print("\nPASS：QC冒烟训练通过")
print("预训练权重：校验并成功加载")
print("训练更新：10步，损失和梯度均为有限值")
print("验证前向：{}帧通过".format(val_frames))
print("输出目录：" + str(OUT))
print("请查看input_preview.png；本次结果不用于设定剔除阈值。")
