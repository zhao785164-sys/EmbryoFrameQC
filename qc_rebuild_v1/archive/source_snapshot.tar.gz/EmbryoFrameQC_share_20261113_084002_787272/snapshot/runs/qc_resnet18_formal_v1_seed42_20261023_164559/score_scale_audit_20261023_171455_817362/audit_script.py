from pathlib import Path
from datetime import datetime
from collections import Counter, defaultdict
import copy
import csv
import hashlib
import importlib.util
import json
import random
import shutil

import numpy as np
import PIL
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
import torchvision
from sklearn.metrics import roc_auc_score, average_precision_score

RUN = Path(
    "/home/gpuserver2/QC_Rebuild_v1/runs/"
    "qc_resnet18_formal_v1_seed42_20261023_164559"
)
REVIEW = RUN / "validation_boundary_review_20261023_170442_615728"

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def read_csv(path):
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    require(bool(rows) and all(
        None not in r and all(v is not None for v in r.values())
        for r in rows
    ), "CSV为空或结构异常：" + str(path))
    return rows

def write_csv(path, rows):
    require(bool(rows), "没有可写入的记录：" + str(path))
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def key(row):
    return row["embryo_id"], int(row["run"])

def buffer_hash(model):
    h = hashlib.sha256()
    for name, value in model.named_buffers():
        h.update(name.encode("utf-8"))
        h.update(str(value.dtype).encode("utf-8"))
        h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()

def quantiles(scores):
    q = np.quantile(scores, [0, 0.05, 0.5, 0.95, 1])
    return dict(zip(
        ["min", "p05", "median", "p95", "max"],
        [float(x) for x in q]
    ))

def confusion(records, threshold):
    y = np.array([int(r["label_invalid"]) for r in records])
    p = np.array([float(r["score_invalid"]) for r in records])
    prediction = p >= threshold
    tp = int(((y == 1) & prediction).sum())
    fn = int(((y == 1) & ~prediction).sum())
    fp = int(((y == 0) & prediction).sum())
    tn = int(((y == 0) & ~prediction).sum())
    return {
        "threshold": threshold, "tp": tp, "fn": fn, "fp": fp, "tn": tn,
        "recall": tp / (tp + fn),
        "keep_false_delete_rate": fp / (fp + tn),
    }

status = json.loads((RUN / "status.json").read_text(encoding="utf-8"))
config = json.loads((RUN / "config.json").read_text(encoding="utf-8"))
review = json.loads(
    (REVIEW / "review_protocol.json").read_text(encoding="utf-8")
)
require(status["status"] == "COMPLETE", "正式训练未完成")
require(PIL.__version__ == config["versions"]["pillow"],
        "Pillow版本与训练时不同")
require(torch.__version__ == config["versions"]["torch"]
        and torchvision.__version__ == config["versions"]["torchvision"],
        "PyTorch或Torchvision版本与训练时不同")
require(torch.cuda.is_available(), "GPU不可用")

weight_path = RUN / "best.pt"
weight_hash_before = sha256(weight_path)
require(weight_hash_before == review["model_sha256"],
        "最佳模型与生成复核图时不同")
require(sha256(RUN / "qc_image_io_v1.py")
        == config["decode_loader_sha256"], "读取函数校验失败")
require(sha256(RUN / "qc_preprocess_v1.py")
        == config["preprocess_sha256"], "预处理函数校验失败")

image_io = load_module("score_audit_io", RUN / "qc_image_io_v1.py")
preprocess = load_module("score_audit_preprocess", RUN / "qc_preprocess_v1.py")

indexes = {
    "train": read_csv(RUN / "train_index.csv"),
    "val": read_csv(RUN / "val_index.csv"),
}
require(len(indexes["train"]) == 11607
        and len(indexes["val"]) == 2454, "索引数量异常")
train_ids = {r["embryo_id"] for r in indexes["train"]}
val_ids = {r["embryo_id"] for r in indexes["val"]}
require(len(train_ids) == 24 and len(val_ids) == 6
        and not train_ids.intersection(val_ids), "胚胎分组异常")

for split, rows in indexes.items():
    require(len({key(r) for r in rows}) == len(rows), "索引存在重复帧")
    require(all(
        r["qc_split"] == split
        and r["review_status"] == "reviewed"
        and r["label_invalid"] == ("1" if r["action"] == "DELETE" else "0")
        for r in rows
    ), "索引分组或标签异常")

require(Counter(int(r["label_invalid"]) for r in indexes["train"])
        == Counter({0: 9629, 1: 1978}), "训练标签数量异常")
require(Counter(int(r["label_invalid"]) for r in indexes["val"])
        == Counter({0: 2366, 1: 88}), "验证标签数量异常")

saved = read_csv(RUN / "best_val_predictions.csv")
saved_lookup = {key(r): r for r in saved}
require(len(saved_lookup) == len(saved) == 2454
        and set(saved_lookup) == {key(r) for r in indexes["val"]},
        "历史验证预测对应关系异常")
for row in indexes["val"]:
    require(saved_lookup[key(row)]["label_invalid"] == row["label_invalid"],
            "历史预测标签与索引冲突")

OUT = RUN / (
    "score_scale_audit_"
    + datetime.now().strftime("%Y%m%d_%H%M%S_%f")
)
OUT.mkdir(exist_ok=False)
shutil.copy2(Path(__file__), OUT / "audit_script.py")

torch.set_num_threads(2)
torch.manual_seed(42)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

# 这是本项目自行生成、且已核对哈希的检查点。
checkpoint = torch.load(
    weight_path, map_location="cpu", weights_only=False
)
require(int(checkpoint["epoch"]) == int(status["best_epoch"]),
        "检查点轮次与状态记录不符")
require(checkpoint["config"]["preprocess_sha256"]
        == config["preprocess_sha256"], "检查点预处理配置不符")

model = torchvision.models.resnet18(weights=None)
model.fc = nn.Linear(model.fc.in_features, 2)
model.load_state_dict(checkpoint["model"], strict=True)
del checkpoint
model = model.to("cuda").eval()
model.requires_grad_(False)
require(all(not m.training for m in model.modules()),
        "原模型未完全进入eval模式")

buffers_before = buffer_hash(model)

# 检查已保存的BatchNorm运行统计，不修改它们。
bn_rows = []
for name, module in model.named_modules():
    if isinstance(module, nn.BatchNorm2d):
        mean = module.running_mean.detach().cpu().numpy()
        var = module.running_var.detach().cpu().numpy()
        require(np.isfinite(mean).all() and np.isfinite(var).all()
                and (var >= 0).all(), "BatchNorm统计非法：" + name)
        bn_rows.append({
            "layer": name,
            "tracked_batches": int(module.num_batches_tracked.item()),
            "running_mean_abs_mean": float(np.abs(mean).mean()),
            "running_var_min": float(var.min()),
            "running_var_median": float(np.median(var)),
            "running_var_max": float(var.max()),
        })
write_csv(OUT / "bn_running_stats.csv", bn_rows)

class QCSet(Dataset):
    def __init__(self, rows):
        self.rows = rows

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        row = self.rows[index]
        data = Path(row["image_path"]).read_bytes()
        require(hashlib.sha256(data).hexdigest() == row["source_sha256"],
                "原图与审计时不同：" + row["image_path"])
        rgb, metadata = image_io.decode_qc_rgb(data)
        try:
            require(metadata["decode_mode"] == row["decode_mode"],
                    "解码方式改变：" + row["image_path"])
            tensor, display, _ = preprocess.prepare_qc(rgb)
            display.close()
        finally:
            rgb.close()
        require(bool(torch.isfinite(tensor).all()), "输入出现NaN/Inf")
        return tensor, int(row["label_invalid"]), index

results = {}
max_formula_difference = 0.0

# 两个集合均使用同一eval模型、batch size=32、无随机增强。
for split in ("train", "val"):
    rows = indexes[split]
    loader = DataLoader(
        QCSet(rows), batch_size=32, shuffle=False, num_workers=0
    )
    predictions = []
    print("\n开始完整{}集eval检查：{}帧".format(split, len(rows)), flush=True)

    with torch.inference_mode():
        for step, (images, labels, indices) in enumerate(loader, 1):
            logits = model(images.to("cuda"))
            require(tuple(logits.shape) == (len(labels), 2)
                    and bool(torch.isfinite(logits).all()),
                    "模型输出非法")

            scores = logits.softmax(dim=1)[:, 1]
            margins = logits[:, 1] - logits[:, 0]
            difference = (
                scores - torch.sigmoid(margins)
            ).abs().max().item()
            max_formula_difference = max(max_formula_difference, difference)

            cpu_logits = logits.cpu().numpy()
            cpu_scores = scores.cpu().numpy()
            cpu_margins = margins.cpu().numpy()

            for j, index in enumerate(indices.tolist()):
                row = rows[index]
                predictions.append({
                    "embryo_id": row["embryo_id"],
                    "run": row["run"],
                    "split": split,
                    "action": row["action"],
                    "label_invalid": int(row["label_invalid"]),
                    "anomaly_type": row["anomaly_type"],
                    "image_path": row["image_path"],
                    "score_invalid": float(cpu_scores[j]),
                    "logit_keep": float(cpu_logits[j, 0]),
                    "logit_invalid": float(cpu_logits[j, 1]),
                    "logit_margin_invalid_minus_keep": float(cpu_margins[j]),
                })

            if step == 1 or step % 100 == 0 or step == len(loader):
                print("{} {}/{} batches".format(
                    split, step, len(loader)
                ), flush=True)

    require(len(predictions) == len(rows), "没有覆盖完整数据")
    results[split] = predictions
    write_csv(OUT / (split + "_eval_predictions.csv"), predictions)

# 分数分布：按集合/标签，以及异常类型分别统计。
distribution_rows = []
type_rows = []
for split, records in results.items():
    for action in ("KEEP", "DELETE"):
        group = [r for r in records if r["action"] == action]
        distribution_rows.append({
            "split": split, "action": action, "frames": len(group),
            **quantiles([r["score_invalid"] for r in group]),
        })

    groups = defaultdict(list)
    for row in records:
        groups[(row["action"], row["anomaly_type"])].append(row)
    for (action, anomaly), group in sorted(groups.items()):
        type_rows.append({
            "split": split, "action": action, "anomaly_type": anomaly,
            "frames": len(group),
            **quantiles([r["score_invalid"] for r in group]),
        })

write_csv(OUT / "score_distributions.csv", distribution_rows)
write_csv(OUT / "score_distributions_by_type.csv", type_rows)

metric_rows = []
for split, records in results.items():
    y = np.array([r["label_invalid"] for r in records])
    p = np.array([r["score_invalid"] for r in records])
    for threshold in (0.5, 0.001):
        metric_rows.append({
            "split": split,
            "auroc": float(roc_auc_score(y, p)),
            "ap": float(average_precision_score(y, p)),
            **confusion(records, threshold),
        })
write_csv(OUT / "metrics_at_reference_thresholds.csv", metric_rows)

# 与原先保存的完整验证分数比较。
new_val = results["val"]
old_p = np.array([
    float(saved_lookup[key(r)]["score_invalid"]) for r in new_val
])
new_p = np.array([r["score_invalid"] for r in new_val])
max_abs_diff = float(np.max(np.abs(old_p - new_p)))
reproduced = bool(np.allclose(new_p, old_p, rtol=1e-4, atol=1e-6))
flip_counts = {
    str(t): int(np.sum((old_p >= t) != (new_p >= t)))
    for t in (0.5, 0.001)
}

# BatchNorm诊断：仅在临时副本中使用批次统计。
# 原模型始终保持eval，副本不保存、不更新运行统计。
probe_model = copy.deepcopy(model).eval()
for module in probe_model.modules():
    if isinstance(module, nn.BatchNorm2d):
        module.train()
        module.track_running_stats = False

probe_rows = []
rng = random.Random(42)

for split in ("train", "val"):
    rows = indexes[split]
    selected = []
    for label in (0, 1):
        pool = [
            i for i, row in enumerate(rows)
            if int(row["label_invalid"]) == label
        ]
        selected.extend(rng.sample(pool, 16))
    rng.shuffle(selected)
    dataset = QCSet(rows)
    images = torch.stack([dataset[i][0] for i in selected]).to("cuda")

    with torch.inference_mode():
        eval_scores = model(images).softmax(dim=1)[:, 1].cpu().numpy()
        batch_scores = probe_model(images).softmax(dim=1)[:, 1].cpu().numpy()

    for j, index in enumerate(selected):
        row = rows[index]
        probe_rows.append({
            "split": split, "embryo_id": row["embryo_id"], "run": row["run"],
            "action": row["action"],
            "score_normal_eval": float(eval_scores[j]),
            "score_temporary_batch_stats": float(batch_scores[j]),
        })

write_csv(OUT / "bn_probe_samples.csv", probe_rows)
bn_summary = []
for split in ("train", "val"):
    for action in ("KEEP", "DELETE"):
        group = [
            r for r in probe_rows
            if r["split"] == split and r["action"] == action
        ]
        bn_summary.append({
            "split": split, "action": action, "frames": len(group),
            "median_normal_eval":
                float(np.median([r["score_normal_eval"] for r in group])),
            "median_temporary_batch_stats": float(np.median([
                r["score_temporary_batch_stats"] for r in group
            ])),
        })
write_csv(OUT / "bn_probe_summary.csv", bn_summary)

buffers_unchanged = buffer_hash(model) == buffers_before
file_unchanged = sha256(weight_path) == weight_hash_before
require(buffers_unchanged and file_unchanged, "原模型状态发生变化")
require(max_formula_difference < 1e-6, "softmax与logit差值公式不一致")

summary = {
    "status": "PASS" if reproduced else "NEEDS_REVIEW",
    "checkpoint_epoch": int(status["best_epoch"]),
    "checkpoint_sha256": weight_hash_before,
    "validation_scores_reproduced": reproduced,
    "reproduction_tolerance": {"rtol": 1e-4, "atol": 1e-6},
    "max_validation_score_abs_diff": max_abs_diff,
    "validation_prediction_flip_counts": flip_counts,
    "max_softmax_vs_sigmoid_margin_difference": max_formula_difference,
    "original_model_buffers_unchanged": buffers_unchanged,
    "checkpoint_file_unchanged": file_unchanged,
    "deployment_threshold_selected": False,
    "independent_test_used": False,
    "bn_probe_note": (
        "32 balanced samples per split; temporary-copy batch-statistics "
        "sensitivity check only. Not a replacement evaluation method "
        "and not evidence of causality."
    ),
}
(OUT / "summary.json").write_text(
    json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8"
)
(OUT / "SHA256SUMS").write_text(
    "\n".join(
        sha256(p) + "  " + p.name
        for p in sorted(OUT.iterdir()) if p.is_file()
    ) + "\n", encoding="utf-8"
)

print("\n=== 完整数据分数分布 ===")
for r in distribution_rows:
    print(
        "{} {} n={} | min {:.6e} median {:.6e} max {:.6e}".format(
            r["split"], r["action"], r["frames"],
            r["min"], r["median"], r["max"]
        )
    )

print("\n=== 按异常类型的分数分布 ===")
for r in type_rows:
    print(
        "{} {} {} n={} | min {:.6e} median {:.6e} max {:.6e}".format(
            r["split"], r["action"], r["anomaly_type"], r["frames"],
            r["min"], r["median"], r["max"]
        )
    )

print("\n=== 完整数据参考阈值结果 ===")
for r in metric_rows:
    print(
        "{} AP {:.6f} AUROC {:.6f} t={} | "
        "TP {} FN {} FP {} TN {} | Recall {:.6f} KEEP误删率 {:.6f}".format(
            r["split"], r["ap"], r["auroc"], r["threshold"],
            r["tp"], r["fn"], r["fp"], r["tn"],
            r["recall"], r["keep_false_delete_rate"]
        )
    )

print("\n=== 验证分数复现 ===")
print("复现通过：", reproduced)
print("最大绝对差：", max_abs_diff)
print("参考阈值下判定变化数量：", flip_counts)

print("\n=== BatchNorm临时副本诊断：不可作为正式评估结果 ===")
for r in bn_summary:
    print(
        "{} {} | 正常eval中位数 {:.6e} | 临时批次统计中位数 {:.6e}".format(
            r["split"], r["action"], r["median_normal_eval"],
            r["median_temporary_batch_stats"]
        )
    )

print("\n原模型缓冲区未改变：", buffers_unchanged)
print("原检查点文件未改变：", file_unchanged)
print("最终诊断状态：", summary["status"])
print("输出目录：", OUT)
print("未训练、未修改人工标签、未固定部署阈值。")
