import csv
import hashlib
import json
import math
import shutil
import sys
from collections import Counter, defaultdict
from pathlib import Path

import torch
import torchvision

root = Path("/home/zhl/projects/QC_Rebuild_v1")
out = Path(sys.argv[1]).resolve()
reference = root / "runs/qc_independent_test_seed42_20261105_170047_313701"
lock = root / "protocols/qc_seed42_test_lock_v1_20261023_172404_001616"
upstream = root / "splits/qc_rebuild_sampling_v1/upstream_split_snapshot.csv"
torch.set_num_threads(2)

def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()

def write_csv(path, rows, fields):
    with path.open("x", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

# 固定上游划分、模型与预处理，独立测试结果保持原样。
record = json.loads((reference / "evaluation_record.json").read_text(encoding="utf-8"))
protocol = json.loads((lock / "test_protocol.json").read_text(encoding="utf-8"))
if (protocol["checkpoint_epoch"] != 6
        or protocol["test_threshold"] != 0.001
        or protocol["label_mapping"] != {"0": "KEEP", "1": "DELETE"}
        or sha256(lock / "model.pt") != protocol["model_sha256"]
        or protocol["model_sha256"] != record["model_sha256"]):
    raise SystemExit("MODEL_PROTOCOL_CHECK_FAILED")

for name in ["qc_image_io_v1.py", "qc_preprocess_v1.py"]:
    if sha256(reference / name) != record["input_hashes"][name]:
        raise SystemExit("PREPROCESS_CHECK_FAILED: " + name)
    if not (out / name).exists():
        shutil.copy2(reference / name, out / name)
    if sha256(out / name) != record["input_hashes"][name]:
        raise SystemExit("本次运行目录的预处理文件不一致。")

if not (out / "model.pt").exists():
    shutil.copy2(lock / "model.pt", out / "model.pt")
if sha256(out / "model.pt") != protocol["model_sha256"]:
    raise SystemExit("本次运行目录的权重校验失败。")
for src, name in [
    (upstream, "upstream_split_snapshot.csv"),
    (lock / "selection.csv", "qc_selection_snapshot.csv"),
    (lock / "test_protocol.json", "model_protocol.json"),
]:
    if not (out / name).exists():
        shutil.copy2(src, out / name)
    if sha256(src) != sha256(out / name):
        raise SystemExit("输入快照发生变化：" + name)

selected = read_csv(out / "qc_selection_snapshot.csv")
population = read_csv(out / "upstream_split_snapshot.csv")
ids = [r["embryo_id"] for r in population]
if len(ids) != 704 or len(set(ids)) != 704:
    raise SystemExit("上游名单不是 704 个唯一胚胎。")
if not {r["embryo_id"] for r in selected}.issubset(set(ids)):
    raise SystemExit("QC 冻结名单与上游名单不一致。")

known = {r["embryo_id"]: Path(r["f0_dir"]) for r in selected}
source_roots = {p.parent for p in known.values()}
groups = {}
manifest = []
problems = []

# 先盘点全部目录；目录缺失或编号冲突时，不启动评分。
import re
for item in population:
    eid = item["embryo_id"]
    candidates = {p.resolve() for p in
                  ([known[eid]] if eid in known else
                   [parent / eid for parent in source_roots])
                  if p.is_dir()}
    if len(candidates) != 1:
        problems.append(f"{eid}: 找不到唯一 F0 目录")
        continue
    folder = candidates.pop()
    frames = []
    try:
        for p in folder.iterdir():
            if p.is_file() and p.suffix.lower() in {".jpg", ".jpeg", ".png"}:
                m = re.search(r"RUN(\d+)$", p.stem, re.I)
                if not m:
                    raise ValueError("无法识别编号：" + p.name)
                frames.append((int(m.group(1)), p))
    except (OSError, ValueError) as exc:
        problems.append(f"{eid}: {exc}")
        continue
    frames.sort()
    if not frames or len({n for n, _ in frames}) != len(frames):
        problems.append(f"{eid}: 无原图或 RUN 重复")
        continue
    rows = [
        dict(embryo_id=eid, upstream_split=item["split"],
             run=n, image_path=str(p))
        for n, p in frames
    ]
    groups[eid] = rows
    manifest.extend(rows)

if problems:
    (out / "inventory_errors.txt").write_text(
        "\n".join(problems), encoding="utf-8")
    raise SystemExit("INVENTORY_FAILED\n" + "\n".join(problems[:20]))

manifest_fields = ["embryo_id", "upstream_split", "run", "image_path"]
manifest_file = out / "f0_manifest.csv"
if manifest_file.exists():
    old = read_csv(manifest_file)
    current = [{k: str(v) for k, v in r.items()} for r in manifest]
    if old != current:
        raise SystemExit("实际原图清单与本次运行已有清单不一致。")
else:
    write_csv(manifest_file, manifest, manifest_fields)

print("INVENTORY_READY:", len(groups), "组 /", len(manifest), "张 F0 原图", flush=True)
print("上游划分：", dict(Counter(r["split"] for r in population)), flush=True)
print("目录：", out, flush=True)

sys.path.insert(0, str(out))
from qc_image_io_v1 import load_qc_rgb
from qc_preprocess_v1 import prepare_qc

# 已验证 SHA256 的自有冻结 checkpoint。
checkpoint = torch.load(out / "model.pt", map_location="cpu", weights_only=False)
if isinstance(checkpoint, dict) and "model" in checkpoint:
    if "epoch" in checkpoint and int(checkpoint["epoch"]) != 6:
        raise SystemExit("checkpoint epoch 不一致。")
    state = checkpoint["model"]
else:
    state = checkpoint
model = torchvision.models.resnet18(weights=None)
model.fc = torch.nn.Linear(model.fc.in_features, 2)
model.load_state_dict(state, strict=True)
model.eval()

result_dir = out / "per_embryo"
result_dir.mkdir(exist_ok=True)
fields = manifest_fields + ["status", "decode_mode", "score_delete",
                            "predicted_action", "error"]
summary_rows = []

for number, (eid, inputs) in enumerate(groups.items(), 1):
    target = result_dir / (eid + ".csv")
    if target.exists():
        rows = read_csv(target)
        expected_keys = {(r["run"], r["image_path"]) for r in inputs}
        actual_keys = {(int(r["run"]), r["image_path"]) for r in rows}
        if len(rows) != len(inputs) or actual_keys != expected_keys:
            raise SystemExit("已有分组输出不完整：" + eid)
        for r in rows:
            if r["status"] == "OK":
                score = float(r["score_delete"])
                if (not 0 <= score <= 1 or r["predicted_action"] !=
                        ("DELETE" if score >= 0.001 else "KEEP")):
                    raise SystemExit("已有分组输出异常：" + eid)
            elif (r["status"] not in {"DECODE_ERROR", "PREPROCESS_ERROR"}
                  or r["predicted_action"] != "REVIEW"):
                raise SystemExit("已有分组输出状态异常：" + eid)
    else:
        rows, pending, tensors = [], [], []

        def flush():
            if not tensors:
                return
            with torch.inference_mode():
                scores = model(torch.stack(tensors)).softmax(dim=1)[:, 1].tolist()
            if not all(math.isfinite(s) for s in scores):
                raise RuntimeError("模型产生非有限分数。")
            for r, score in zip(pending, scores):
                r.update(status="OK", score_delete=score,
                         predicted_action="DELETE" if score >= 0.001 else "KEEP")
                rows.append(r)
            pending.clear()
            tensors.clear()

        for item in inputs:
            r = dict(item, status="", decode_mode="", score_delete="",
                     predicted_action="REVIEW", error="")
            try:
                rgb, meta = load_qc_rgb(Path(item["image_path"]))
            except Exception as exc:
                r.update(status="DECODE_ERROR", error=repr(exc))
            else:
                try:
                    with rgb:
                        r["decode_mode"] = meta["decode_mode"]
                        tensor, display, _ = prepare_qc(rgb)
                        display.close()
                    if not torch.isfinite(tensor).all().item():
                        raise ValueError("预处理张量包含 NaN/Inf")
                except Exception as exc:
                    r.update(status="PREPROCESS_ERROR", error=repr(exc))
            if r["status"]:
                rows.append(r)
            else:
                pending.append(r)
                tensors.append(tensor)
            if len(tensors) == 32:
                flush()
        flush()
        rows.sort(key=lambda r: int(r["run"]))
        temporary = target.with_suffix(".tmp")
        with temporary.open("w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            w.writerows(rows)
        temporary.replace(target)

    counts = Counter(r["predicted_action"] for r in rows)
    summary_rows.append(dict(
        embryo_id=eid, upstream_split=inputs[0]["upstream_split"],
        total=len(rows), KEEP=counts["KEEP"], DELETE=counts["DELETE"],
        REVIEW=counts["REVIEW"]))
    print(f"[{number}/704] {eid}: {dict(counts)}", flush=True)

summary_path = out / "per_embryo_summary.csv"
if not summary_path.exists():
    write_csv(summary_path, summary_rows, list(summary_rows[0]))
totals = {key: sum(r[key] for r in summary_rows)
          for key in ["total", "KEEP", "DELETE", "REVIEW"]}
report = dict(
    status="INFERENCE_COMPLETE", embryos=len(groups), **totals,
    threshold=0.001, model_sha256=protocol["model_sha256"],
    manifest_sha256=sha256(manifest_file),
    scope="F0 inference only; source images preserved",
)
(out / "batch_summary.json").write_text(
    json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(report, indent=2, ensure_ascii=False), flush=True)
