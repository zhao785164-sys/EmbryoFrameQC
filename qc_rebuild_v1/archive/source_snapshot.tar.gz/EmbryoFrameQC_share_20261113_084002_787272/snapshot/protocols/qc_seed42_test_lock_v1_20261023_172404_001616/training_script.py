from pathlib import Path
from collections import Counter
import csv
import hashlib
import importlib.util
import json
import os
import random
import shutil
import sys
import time
import traceback

import numpy as np
import PIL
import torch
import torch.nn.functional as F
from torch import nn
from torch.utils.data import Dataset, DataLoader
import torchvision
from sklearn.metrics import (
    roc_auc_score, average_precision_score,
    precision_score, recall_score, f1_score,
    accuracy_score, balanced_accuracy_score
)

ROOT = Path("/home/gpuserver2/QC_Rebuild_v1")
AUDIT = ROOT / "data/qc30_decode_audit_v1_20261023_162958_452370"
SMOKE = ROOT / "runs/qc_resnet18_smoke_v1_20261023_163631_774005"
OUT = Path(__file__).resolve().parent
SEED, EPOCHS, BATCH = 42, 10, 32
LR, WD = 1e-4, 1e-4

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def save_json(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)
        + "\n", encoding="utf-8"
    )
    os.replace(str(temporary), str(path))

def save_checkpoint(path, value):
    temporary = path.with_name(path.name + ".tmp")
    torch.save(value, temporary)
    os.replace(str(temporary), str(path))

def write_csv(path, fields, rows):
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    os.replace(str(temporary), str(path))

def verify_manifest(folder):
    for line in (folder / "SHA256SUMS").read_text(
        encoding="utf-8"
    ).splitlines():
        if not line.strip():
            continue
        digest, name = line.split("  ", 1)
        require(Path(name).name == name, "校验清单文件名异常")
        path = folder / name
        require(path.is_file() and sha256(path) == digest,
                "校验失败：" + str(path))

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def worker_init(worker_id):
    seed = torch.initial_seed() % (2 ** 32)
    random.seed(seed)
    np.random.seed(seed)
    torch.set_num_threads(1)

class QCSet(Dataset):
    def __init__(self, rows, image_io, preprocess):
        self.rows = rows
        self.image_io = image_io
        self.preprocess = preprocess

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        row = self.rows[index]
        data = Path(row["image_path"]).read_bytes()
        require(hashlib.sha256(data).hexdigest() == row["source_sha256"],
                "原图与审计时不同：" + row["image_path"])
        rgb, metadata = self.image_io.decode_qc_rgb(data)
        try:
            require(metadata["decode_mode"] == row["decode_mode"],
                    "解码方式与审计记录不一致")
            tensor, display, _ = self.preprocess.prepare_qc(rgb)
            display.close()
        finally:
            rgb.close()
        require(bool(torch.isfinite(tensor).all()), "输入出现NaN/Inf")
        return tensor, int(row["label_invalid"])

def cpu_model_state(model):
    return {k: v.detach().cpu() for k, v in model.state_dict().items()}

def main():
    started = time.monotonic()
    print("开始QC正式基线：seed42，10轮，物理GPU0", flush=True)
    save_json(OUT / "status.json", {
        "status": "RUNNING", "pid": os.getpid(), "completed_epochs": 0
    })

    verify_manifest(AUDIT)
    verify_manifest(SMOKE)
    audit_config = json.loads(
        (AUDIT / "audit_protocol.json").read_text(encoding="utf-8")
    )
    smoke_config = json.loads(
        (SMOKE / "config.json").read_text(encoding="utf-8")
    )
    smoke_result = json.loads(
        (SMOKE / "result.json").read_text(encoding="utf-8")
    )
    require(audit_config["status"] == "PASS"
            and smoke_result["status"] == "PASS",
            "解码审计或冒烟测试未通过")
    require(audit_config["pillow"] == PIL.__version__,
            "Pillow版本已变化")
    require(torch.cuda.is_available(), "GPU不可用")

    for name in ("qc_image_io_v1.py", "qc_preprocess_v1.py"):
        shutil.copy2(SMOKE / name, OUT / name)

    image_io = load_module("formal_image_io", OUT / "qc_image_io_v1.py")
    preprocess = load_module("formal_preprocess", OUT / "qc_preprocess_v1.py")
    require(sha256(OUT / "qc_image_io_v1.py")
            == audit_config["loader_sha256"], "读取函数与审计时不同")
    require(sha256(OUT / "qc_preprocess_v1.py")
            == smoke_config["preprocess_sha256"], "预处理函数已变化")

    index = AUDIT / "qc30_frame_index_audited.csv"
    with index.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        fields = reader.fieldnames
        rows = list(reader)

    require(len(rows) == 14061
            and Counter(r["action"] for r in rows)
                == Counter({"KEEP": 11995, "DELETE": 2066}),
            "索引数量异常")
    require(all(
        r["qc_split"] in ("train", "val")
        and r["review_status"] == "reviewed"
        and r["decode_mode"] in ("STRICT_OK", "TRUNCATED_ALLOWED")
        and r["label_invalid"] == (
            "1" if r["action"] == "DELETE" else "0"
        ) for r in rows
    ), "索引标签、分组或状态异常")
    require(len({(r["embryo_id"], r["run"]) for r in rows}) == len(rows),
            "索引存在重复帧")

    train_rows = [r for r in rows if r["qc_split"] == "train"]
    val_rows = [r for r in rows if r["qc_split"] == "val"]
    train_ids = {r["embryo_id"] for r in train_rows}
    val_ids = {r["embryo_id"] for r in val_rows}
    require(len(train_ids) == 24 and len(val_ids) == 6
            and not train_ids.intersection(val_ids), "胚胎分组异常")
    require(len(train_rows) == 11607 and len(val_rows) == 2454,
            "训练/验证帧数异常")

    write_csv(OUT / "train_index.csv", fields, train_rows)
    write_csv(OUT / "val_index.csv", fields, val_rows)

    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

    counts = Counter(int(r["label_invalid"]) for r in train_rows)
    class_weight_values = [
        len(train_rows) / (2 * counts[label]) for label in (0, 1)
    ]
    class_weights = torch.tensor(class_weight_values, device="cuda")

    weight_path = Path(smoke_config["weights_path"])
    require(sha256(weight_path) == smoke_config["weights_sha256"],
            "ImageNet权重校验失败")

    # 从原始ImageNet权重重新初始化，未加载冒烟模型。
    model = torchvision.models.resnet18(weights=None)
    model.load_state_dict(
        torch.load(weight_path, map_location="cpu", weights_only=True),
        strict=True
    )
    model.fc = nn.Linear(model.fc.in_features, 2)
    model = model.to("cuda")
    optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WD)

    generator = torch.Generator().manual_seed(SEED)
    train_loader = DataLoader(
        QCSet(train_rows, image_io, preprocess),
        batch_size=BATCH, shuffle=True, num_workers=2,
        pin_memory=True, persistent_workers=True,
        worker_init_fn=worker_init, generator=generator
    )
    val_loader = DataLoader(
        QCSet(val_rows, image_io, preprocess),
        batch_size=BATCH, shuffle=False, num_workers=2,
        pin_memory=True, persistent_workers=True,
        worker_init_fn=worker_init
    )

    config = {
        "seed": SEED, "epochs": EPOCHS, "batch_size": BATCH,
        "learning_rate": LR, "weight_decay": WD,
        "optimizer": "AdamW", "augmentation": "none",
        "loss": "train-count-weighted cross entropy",
        "class_weights_keep_delete": class_weight_values,
        "train_embryos": 24, "val_embryos": 6,
        "train_frames": len(train_rows), "val_frames": len(val_rows),
        "model_selection": "highest val AP, then lowest unweighted val CE",
        "metric_threshold": 0.5,
        "threshold_status": "diagnostic only; deployment threshold not selected",
        "physical_gpu": 0,
        "independent_test_used": False,
        "initialization": "fresh ImageNet weights; not smoke checkpoint",
        "weights_path": str(weight_path),
        "weights_sha256": sha256(weight_path),
        "index_path": str(index), "index_sha256": sha256(index),
        "decode_loader_sha256": sha256(OUT / "qc_image_io_v1.py"),
        "preprocess_sha256": sha256(OUT / "qc_preprocess_v1.py"),
        "preprocessing": smoke_config["preprocessing"],
        "preprocessing_status": "fixed for this baseline",
        "validation_limitation":
            "88 DELETE frames from AM365-7 blur interval only",
        "versions": {
            "python": sys.version.split()[0], "torch": torch.__version__,
            "torchvision": torchvision.__version__, "pillow": PIL.__version__,
            "numpy": np.__version__,
        },
    }
    save_json(OUT / "config.json", config)

    print("训练：11607帧；验证：2454帧", flush=True)
    print("类别权重 KEEP/DELETE：" + str(class_weight_values), flush=True)
    print("GPU：" + torch.cuda.get_device_name(0), flush=True)

    history = []
    best_ap, best_ce, best_epoch = -1.0, float("inf"), 0

    for epoch in range(1, EPOCHS + 1):
        epoch_started = time.monotonic()
        model.train()
        numerator, denominator = 0.0, 0.0

        for step, (images, labels) in enumerate(train_loader, 1):
            images = images.to("cuda", non_blocking=True)
            labels = labels.to("cuda", non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            logits = model(images)
            weighted_sum = F.cross_entropy(
                logits, labels, weight=class_weights, reduction="sum"
            )
            batch_weight = class_weights[labels].sum()
            loss = weighted_sum / batch_weight
            require(bool(torch.isfinite(loss)), "训练损失出现NaN/Inf")
            loss.backward()
            grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            require(bool(torch.isfinite(grad_norm)), "梯度出现NaN/Inf")
            optimizer.step()
            numerator += float(weighted_sum.detach().cpu())
            denominator += float(batch_weight.detach().cpu())

            if step == 1 or step % 50 == 0 or step == len(train_loader):
                print(
                    "epoch {}/{} step {}/{} | train CE {:.6f}".format(
                        epoch, EPOCHS, step, len(train_loader),
                        numerator / denominator
                    ), flush=True
                )

        model.eval()
        probabilities, targets = [], []
        val_loss_sum = 0.0
        with torch.inference_mode():
            for images, labels in val_loader:
                images = images.to("cuda", non_blocking=True)
                labels = labels.to("cuda", non_blocking=True)
                logits = model(images)
                require(bool(torch.isfinite(logits).all()),
                        "验证输出出现NaN/Inf")
                val_loss_sum += float(F.cross_entropy(
                    logits, labels, reduction="sum"
                ).cpu())
                probabilities.extend(
                    logits.softmax(dim=1)[:, 1].cpu().tolist()
                )
                targets.extend(labels.cpu().tolist())

        require(len(targets) == len(val_rows), "验证未覆盖全部帧")
        y = np.asarray(targets)
        p = np.asarray(probabilities)
        pred = (p >= 0.5).astype(int)
        tp = int(((y == 1) & (pred == 1)).sum())
        fn = int(((y == 1) & (pred == 0)).sum())
        fp = int(((y == 0) & (pred == 1)).sum())
        tn = int(((y == 0) & (pred == 0)).sum())

        metrics = {
            "epoch": epoch,
            "train_weighted_ce": numerator / denominator,
            "val_ce": val_loss_sum / len(y),
            "val_auroc": float(roc_auc_score(y, p)),
            "val_ap": float(average_precision_score(y, p)),
            "val_accuracy": float(accuracy_score(y, pred)),
            "val_balanced_accuracy": float(balanced_accuracy_score(y, pred)),
            "val_precision": float(precision_score(y, pred, zero_division=0)),
            "val_recall": float(recall_score(y, pred, zero_division=0)),
            "val_f1": float(f1_score(y, pred, zero_division=0)),
            "val_keep_false_delete_rate": fp / (fp + tn),
            "val_brier": float(np.mean((p - y) ** 2)),
            "tp": tp, "fn": fn, "fp": fp, "tn": tn,
            "threshold": 0.5,
            "epoch_seconds": time.monotonic() - epoch_started,
        }
        history.append(metrics)

        predictions = [{
            "embryo_id": row["embryo_id"], "run": row["run"],
            "image_path": row["image_path"],
            "label_invalid": int(row["label_invalid"]),
            "score_invalid": float(score),
            "prediction_at_0_5": int(score >= 0.5),
            "anomaly_type": row["anomaly_type"],
            "decode_mode": row["decode_mode"],
        } for row, score in zip(val_rows, probabilities)]

        write_csv(
            OUT / ("val_predictions_epoch{:02d}.csv".format(epoch)),
            list(predictions[0]), predictions
        )
        write_csv(OUT / "history.csv", list(history[0]), history)

        # 按胚胎保存误删、漏检数量，避免总体指标掩盖个别组问题。
        per_embryo = []
        for embryo in sorted(val_ids):
            group = [r for r in predictions if r["embryo_id"] == embryo]
            group_tp = sum(r["label_invalid"] == 1
                           and r["prediction_at_0_5"] == 1 for r in group)
            group_fn = sum(r["label_invalid"] == 1
                           and r["prediction_at_0_5"] == 0 for r in group)
            group_fp = sum(r["label_invalid"] == 0
                           and r["prediction_at_0_5"] == 1 for r in group)
            group_tn = sum(r["label_invalid"] == 0
                           and r["prediction_at_0_5"] == 0 for r in group)
            per_embryo.append({
                "embryo_id": embryo, "frames": len(group),
                "tp": group_tp, "fn": group_fn,
                "fp": group_fp, "tn": group_tn,
            })
        write_csv(
            OUT / ("val_embryos_epoch{:02d}.csv".format(epoch)),
            list(per_embryo[0]), per_embryo
        )

        improved = (
            metrics["val_ap"] > best_ap + 1e-12
            or (
                abs(metrics["val_ap"] - best_ap) <= 1e-12
                and metrics["val_ce"] < best_ce
            )
        )
        if improved:
            best_ap = metrics["val_ap"]
            best_ce = metrics["val_ce"]
            best_epoch = epoch
            save_checkpoint(OUT / "best.pt", {
                "model": cpu_model_state(model),
                "epoch": epoch, "metrics": metrics, "config": config,
                "deployment_threshold": None,
            })
            save_json(OUT / "best_metrics.json", metrics)
            write_csv(
                OUT / "best_val_predictions.csv",
                list(predictions[0]), predictions
            )

        save_checkpoint(OUT / "last.pt", {
            "model": cpu_model_state(model),
            "optimizer": optimizer.state_dict(),
            "epoch": epoch, "history": history, "config": config,
            "best_ap": best_ap, "best_ce": best_ce, "best_epoch": best_epoch,
            "torch_rng_state": torch.get_rng_state(),
            "cuda_rng_state": torch.cuda.get_rng_state(),
            "shuffle_generator_state": generator.get_state(),
            "python_rng_state": random.getstate(),
            "numpy_rng_state": np.random.get_state(),
        })
        save_json(OUT / "status.json", {
            "status": "RUNNING", "pid": os.getpid(),
            "completed_epochs": epoch, "best_epoch": best_epoch,
            "best_val_ap": best_ap,
        })
        print(
            "EPOCH {} DONE | AP {:.6f} AUROC {:.6f} F1 {:.6f} "
            "Recall {:.6f} KEEP误删率 {:.6f} | best epoch {}".format(
                epoch, metrics["val_ap"], metrics["val_auroc"],
                metrics["val_f1"], metrics["val_recall"],
                metrics["val_keep_false_delete_rate"], best_epoch
            ), flush=True
        )

    save_json(OUT / "status.json", {
        "status": "COMPLETE", "pid": os.getpid(),
        "completed_epochs": EPOCHS, "best_epoch": best_epoch,
        "best_val_ap": best_ap,
        "elapsed_seconds": time.monotonic() - started,
        "deployment_threshold_selected": False,
        "independent_test_used": False,
    })
    print("\nPASS：seed42正式基线完成10轮", flush=True)
    print("最佳轮次：" + str(best_epoch), flush=True)
    print("输出目录：" + str(OUT), flush=True)
    print("尚未选择部署阈值，尚未评估独立测试集。", flush=True)

if __name__ == "__main__":
    try:
        main()
    except BaseException as error:
        save_json(OUT / "status.json", {
            "status": "FAILED", "pid": os.getpid(),
            "error": type(error).__name__ + ": " + str(error),
        })
        traceback.print_exc()
        sys.exit(1)
