from pathlib import Path
from datetime import datetime
from collections import Counter
import csv
import hashlib
import importlib.util
import json
import os
import re
import shutil
import tarfile

import numpy as np
import PIL
from PIL import Image, ImageOps, ImageDraw, ImageFont
import torch

ROOT = Path("/home/gpuserver2/QC_Rebuild_v1")
RUN = ROOT / "runs/qc_resnet18_formal_v1_seed42_20261023_164559"
AUDIT = RUN / "score_scale_audit_20261023_171455_817362"
REVIEW = RUN / "validation_boundary_review_20261023_170442_615728"
LABELS = ROOT / "data/qc30_labels_v1_20261023_155615_176150"
SOURCE = Path(
    "/home/gpuserver2/datasets/nantes_v3/extracted/f0/embryo_dataset"
)
DEST = Path("/home/gpuserver2/QC_Backups")
STAMP = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
THRESHOLD = 0.001
torch.set_num_threads(2)

def require(ok, message):
    if not ok:
        raise SystemExit("停止：" + message)

def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def read_csv(path):
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        fields = reader.fieldnames
        rows = list(reader)
    require(bool(fields) and all(
        None not in r and all(v is not None for v in r.values())
        for r in rows
    ), "CSV结构异常：" + str(path))
    return fields, rows

def write_csv(path, fields, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

def save_json(path, data):
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8"
    )

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

status = json.loads((RUN / "status.json").read_text(encoding="utf-8"))
config = json.loads((RUN / "config.json").read_text(encoding="utf-8"))
diagnosis = json.loads((AUDIT / "summary.json").read_text(encoding="utf-8"))
review = json.loads(
    (REVIEW / "review_protocol.json").read_text(encoding="utf-8")
)
require(status["status"] == "COMPLETE", "训练尚未完成")
require(diagnosis["status"] == "PASS"
        and diagnosis["validation_scores_reproduced"]
        and diagnosis["original_model_buffers_unchanged"]
        and diagnosis["checkpoint_file_unchanged"],
        "分数尺度诊断未通过")
require(sha256(RUN / "best.pt") == diagnosis["checkpoint_sha256"]
        == review["model_sha256"], "最佳模型哈希不一致")
require(PIL.__version__ == config["versions"]["pillow"],
        "Pillow版本改变")
require(sha256(RUN / "qc_image_io_v1.py")
        == config["decode_loader_sha256"], "读取函数校验失败")
require(sha256(RUN / "qc_preprocess_v1.py")
        == config["preprocess_sha256"], "预处理函数校验失败")

# 使用最终标注快照中的固定名单。
for line in (LABELS / "SHA256SUMS").read_text(
    encoding="utf-8"
).splitlines():
    if not line.strip():
        continue
    digest, name = line.split("  ", 1)
    require(Path(name).name == name
            and sha256(LABELS / name) == digest,
            "标注快照校验失败：" + name)

selection_fields, selection = read_csv(LABELS / "selection.csv")
require(Counter(r["qc_split"] for r in selection)
        == Counter({"train": 24, "val": 6, "test": 15}),
        "固定名单数量不是24/6/15")
require(len({r["embryo_id"] for r in selection}) == 45,
        "固定名单存在重复胚胎")
test_rows = [r for r in selection if r["qc_split"] == "test"]
if "upstream_split" in selection_fields:
    require(all(r["upstream_split"] == "test" for r in test_rows),
            "测试组与上游分组不一致")

# 此脚本用于首次启动测试标注，避免跳过已有的部分标注。
_, current_segments = read_csv(ROOT / "annotations/manual_segments.csv")
test_ids = {r["embryo_id"] for r in test_rows}
existing = {
    r["embryo_id"] for r in current_segments
    if r["embryo_id"] in test_ids and r["focal_plane"] == "F0"
}
require(not existing,
        "预留测试组已有标注，请先核对，勿重复启动：" + str(sorted(existing)))

_, predictions = read_csv(RUN / "best_val_predictions.csv")
keep_scores = [float(r["score_invalid"]) for r in predictions
               if r["label_invalid"] == "0"]
delete_scores = [float(r["score_invalid"]) for r in predictions
                 if r["label_invalid"] == "1"]
require(max(keep_scores) < THRESHOLD <= min(delete_scores),
        "0.001不在当前验证集的两类分数之间")

# 保存一个独立测试基线包。
LOCK = ROOT / "protocols" / ("qc_seed42_test_lock_v1_" + STAMP)
LOCK.mkdir(parents=True, exist_ok=False)
copies = {
    "model.pt": RUN / "best.pt",
    "qc_image_io_v1.py": RUN / "qc_image_io_v1.py",
    "qc_preprocess_v1.py": RUN / "qc_preprocess_v1.py",
    "training_config.json": RUN / "config.json",
    "training_script.py": RUN / "train.py",
    "training_history.csv": RUN / "history.csv",
    "best_metrics.json": RUN / "best_metrics.json",
    "best_val_predictions.csv": RUN / "best_val_predictions.csv",
    "score_scale_audit_summary.json": AUDIT / "summary.json",
    "selection.csv": LABELS / "selection.csv",
    "manual_segments_snapshot.csv": LABELS / "manual_segments.csv",
    "manual_boundaries_snapshot.csv": LABELS / "manual_boundaries.csv",
    "prepare_test_script.py": Path(__file__),
}
for name, source in copies.items():
    shutil.copy2(source, LOCK / name)
    require(sha256(source) == sha256(LOCK / name),
            "基线复制校验失败：" + name)

write_csv(LOCK / "test_selection.csv", selection_fields, test_rows)
save_json(LOCK / "test_protocol.json", {
    "version": "qc_seed42_independent_test_v1",
    "purpose": "independent test evaluation; not whole-library cleaning",
    "source_run": str(RUN),
    "checkpoint_epoch": int(status["best_epoch"]),
    "model_sha256": sha256(LOCK / "model.pt"),
    "score": "softmax(logits,dim=1)[:,1]",
    "label_mapping": {"0": "KEEP", "1": "DELETE"},
    "decision_rule": "score >= 0.001 => DELETE",
    "test_threshold": THRESHOLD,
    "threshold_source": "development validation data only",
    "test_embryos": [r["embryo_id"] for r in test_rows],
    "annotation_policy": (
        "Assess technical usability with raw and prescribed normalized views; "
        "do not infer biological viability; decode errors are separate; "
        "no model scores shown during annotation."
    ),
    "validation_limitation": "88 DELETE frames from one blur embryo",
    "deployment_approved": False,
})
(LOCK / "SHA256SUMS").write_text(
    "\n".join(
        sha256(p) + "  " + p.name
        for p in sorted(LOCK.iterdir()) if p.is_file()
    ) + "\n", encoding="utf-8"
)

DEST.mkdir(parents=True, exist_ok=True)
archive = DEST / ("qc_seed42_test_lock_" + STAMP + ".tar.gz")
with tarfile.open(str(archive), "x:gz", compresslevel=3) as tar:
    tar.add(str(LOCK), arcname=LOCK.name)
digest = sha256(archive)
Path(str(archive) + ".sha256").write_text(
    digest + "  " + archive.name + "\n", encoding="utf-8"
)
latest = DEST / "qc_seed42_test_lock_latest.tar.gz"
temporary = DEST / ("test_lock_link_" + STAMP + ".tmp")
temporary.symlink_to(archive.name)
os.replace(str(temporary), str(latest))
latest_sha = DEST / "qc_seed42_test_lock_latest.tar.gz.sha256"
temporary_sha = DEST / ("test_lock_sha_" + STAMP + ".tmp")
temporary_sha.write_text(
    digest + "  " + latest.name + "\n", encoding="utf-8"
)
os.replace(str(temporary_sha), str(latest_sha))
print("基线已锁定并打包：" + str(archive), flush=True)

# 生成原固定名单前3组的盲标图，不进行模型推理。
image_io = load_module("test_review_io", LOCK / "qc_image_io_v1.py")
preprocess = load_module("test_review_preprocess", LOCK / "qc_preprocess_v1.py")
BATCH = ROOT / "test_review" / ("batch01_" + STAMP)
BATCH.mkdir(parents=True, exist_ok=False)
write_csv(BATCH / "batch_selection.csv", selection_fields, test_rows[:3])

try:
    font = ImageFont.truetype(
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14
    )
except OSError:
    font = ImageFont.load_default()

CELL_W, CELL_H = 400, 238
COLS, PER_PAGE, TOP = 4, 24, 64

def new_page(title):
    canvas = Image.new("RGB", (COLS * CELL_W, TOP + 6 * CELL_H), "white")
    draw = ImageDraw.Draw(canvas)
    draw.text((12, 10), title, fill="black", font=font)
    draw.text(
        (12, 32), "Blind review | RAW + prescribed QC input | no model scores",
        fill="black", font=font
    )
    return canvas

def thumb(image):
    fitted = ImageOps.contain(
        image, (192, 192), method=Image.Resampling.BILINEAR
    )
    canvas = Image.new("RGB", (192, 192), "black")
    canvas.paste(
        fitted, ((192 - fitted.width) // 2, (192 - fitted.height) // 2)
    )
    fitted.close()
    return canvas

print("\n固定的15组测试胚胎：", flush=True)
for i, row in enumerate(test_rows, 1):
    print("{:02d}. {}".format(i, row["embryo_id"]), flush=True)

for selected in test_rows[:3]:
    embryo = selected["embryo_id"]
    source = SOURCE / embryo
    require(source.is_dir(), "原图目录不存在：" + str(source))
    files = {}
    for p in source.iterdir():
        if not p.is_file() or p.suffix.lower() not in {
            ".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"
        }:
            continue
        match = re.search(r"_RUN(\d+)$", p.stem, re.IGNORECASE)
        require(match is not None, "无法解析RUN：" + str(p))
        run = int(match.group(1))
        require(run >= 1 and run not in files, embryo + "的RUN非法或重复")
        files[run] = p
    require(bool(files), embryo + "没有原图")
    ordered = sorted(files)
    OUT = BATCH / (embryo + "_F0")
    OUT.mkdir()
    overview_indices = sorted(set(
        np.linspace(0, len(ordered) - 1, min(24, len(ordered)), dtype=int)
        .tolist()
    ))
    overview_positions = {index: slot for slot, index in enumerate(overview_indices)}
    overview = new_page(
        "{} F0 overview: {}/{} sampled frames; review all pages".format(
            embryo, len(overview_indices), len(ordered)
        )
    )
    index_rows, error_rows = [], []
    page = None

    for i, run in enumerate(ordered):
        page_number = i // PER_PAGE + 1
        start = (i // PER_PAGE) * PER_PAGE
        page_runs = ordered[start:start + PER_PAGE]
        page_name = "page_{:03d}_RUN{}-{}.png".format(
            page_number, page_runs[0], page_runs[-1]
        )
        if i % PER_PAGE == 0:
            page = new_page(
                "{} F0 page {} | {} actual frames".format(
                    embryo, page_number, len(page_runs)
                )
            )
        path = files[run]
        tile = Image.new("RGB", (CELL_W, CELL_H), "white")
        draw = ImageDraw.Draw(tile)
        record = {
            "embryo_id": embryo, "focal_plane": "F0", "run": run,
            "image_path": str(path), "review_page": page_name,
            "source_sha256": "", "decode_mode": "",
            "display_status": "FAILED", "error": "",
        }
        try:
            data = path.read_bytes()
            record["source_sha256"] = hashlib.sha256(data).hexdigest()
            rgb, metadata = image_io.decode_qc_rgb(data)
            try:
                record["decode_mode"] = metadata["decode_mode"]
                tensor, processed, stats = preprocess.prepare_qc(rgb)
                try:
                    require(bool(torch.isfinite(tensor).all()),
                            "预处理张量有NaN/Inf")
                    raw_view, processed_view = thumb(rgb), thumb(processed)
                    tile.paste(raw_view, (4, 36))
                    tile.paste(processed_view, (204, 36))
                    raw_view.close()
                    processed_view.close()
                finally:
                    processed.close()
            finally:
                rgb.close()
            record["display_status"] = "OK"
        except Exception as error:
            if isinstance(error, image_io.QCDecodeError):
                record["decode_mode"] = "FAILED"
            record["error"] = type(error).__name__ + ": " + str(error)
            draw.rectangle((4, 36, 396, 228), fill=(90, 90, 90))
            draw.text((20, 100), "READ / DISPLAY ERROR",
                      fill=(255, 180, 180), font=font)
            error_rows.append({
                "run": run, "image_path": str(path), "error": record["error"]
            })

        draw.text(
            (4, 0), "RUN {} | {}".format(run, record["decode_mode"]),
            fill="black", font=font
        )
        draw.text((4, 18), "RAW", fill="black", font=font)
        draw.text((204, 18), "P1-P99 INPUT", fill="black", font=font)
        slot = i % PER_PAGE
        page.paste(tile, ((slot % COLS) * CELL_W, TOP + (slot // COLS) * CELL_H))
        if i in overview_positions:
            slot = overview_positions[i]
            overview.paste(
                tile, ((slot % COLS) * CELL_W, TOP + (slot // COLS) * CELL_H)
            )
        tile.close()
        index_rows.append(record)

        if (i + 1) % PER_PAGE == 0 or i == len(ordered) - 1:
            page.save(OUT / page_name)
            page.close()
        if (i + 1) % 100 == 0:
            print("{}：{}/{}".format(embryo, i + 1, len(ordered)), flush=True)

    overview.save(OUT / "00_overview.png")
    overview.close()
    write_csv(OUT / "frame_index.csv", list(index_rows[0]), index_rows)
    write_csv(
        OUT / "display_errors.csv", ["run", "image_path", "error"], error_rows
    )
    save_json(OUT / "source_summary.json", {
        "embryo_id": embryo, "actual_frames": len(ordered),
        "first_run": min(ordered), "last_run": max(ordered),
        "missing_runs": sorted(set(range(1, max(ordered) + 1)) - set(ordered)),
        "display_errors": len(error_rows),
        "baseline_protocol": str(LOCK / "test_protocol.json"),
        "annotation_created": False, "model_inference_performed": False,
    })
    print(
        "{}完成：{}帧，显示失败{}，目录：{}".format(
            embryo, len(ordered), len(error_rows), OUT
        ), flush=True
    )

print("\n完成：独立测试基线已保存，前3组盲标图已生成")
print("基线目录：" + str(LOCK))
print("复核批次目录：" + str(BATCH))
print("备份下载入口：" + str(latest))
print("尚未写入测试标签，尚未计算测试预测。")
